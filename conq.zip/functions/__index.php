<?php 

require_once 'functions-db.php';
require_once 'functions-helpers.php';
require_once 'functions-scrapers.php';