  </main>

  <footer class="mastfooter">

  </footer>
 
  <script src="<?php echo get_home_url(); ?>/assets/dist/js/mainjs.js""></script>
</body>